<!--footer-->
    <div class="footer">
       <p>&copy; 2024 BPMS Admin Panel.</p>
    </div>
        <!--//footer-->